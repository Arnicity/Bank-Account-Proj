// c++ code
#include <iostream>
using namespace std;

// make Account number & Balance Global variable because we need them in every
// function
string accountNo;
double balance;

// A function for showing menu to the user
void menu() {
  cout << "N- New account" << endl;
  cout << "W- Withdrawal" << endl;
  cout << "D- Deposit" << endl;
  cout << "B- Balance" << endl;
  cout << "Q- Quit" << endl;
  cout << "X- Delete Account" << endl;
}

// Following are the functions specified in the statement
void newAccount() {
  // Wants to create a new account
  cout << "\n<!---Going to create a new Account--!>" << endl;
  cout << "Enter account number: ";
  cin >> accountNo;
  cout << "Enter your balance: ";
  cin >> balance;

  cout << "\n************Account Created successfully!!***************" << endl;
}

void withdrawal() {
  // Wants to withdraw amount
  double withdrawAmount;
  cout << "Enter amount to withdraw: ";
  cin >> withdrawAmount;

  // check that balance is more than withdraw
  if (balance >= withdrawAmount) {
    // deduct that amount from customer's account balance
    balance = balance - withdrawAmount;
    cout << "\n***************$" << withdrawAmount
         << " has been withdrawed sccessfully***************" << endl;
  } // else there is not enough amount in user account to withdraw
  else {
    cout << "\n***************There is not enough balance in your "
            "account***************"
         << endl;
  }
}

void deposit() {
  double depositAmount;
  cout << "Enter amount to deposit: ";
  cin >> depositAmount;

  // Adding that amount into user balance
  balance = balance + depositAmount;

  cout << "\n***************$" << depositAmount
       << " has been successfully deposited in your account***************"
       << endl;
}

void Balance() {
  // show user's account balance to him/her
  cout << "\n***************Your account balance is $" << balance
       << "***************" << endl;
}

void quit() { exit(0); }

void deleteAccount() {
  // Just delete the account by setting accountNO to null & balance to 0
  accountNo = "";
  balance = 0.0;
  cout << "\n********Account deleted successfully********" << endl;
}

int main() {
  // A string for account number & double variable for balance
  string accountNo = "";
  double balance = 0;
  cout << "\n----Banking Transaction System----" << endl;
  // For selection of any option from menu, declaring a char type variable
  char opt;

  // calling the function menu() as specified in the statement

  menu();
  // After showing menu, taking input from user which option he wants to select
  cout << "What you want to do : ";
  cin >> opt;

  // Now determine which he has entered & perform the respective action

  if (opt == 'N' || opt == 'n') {
    newAccount();
    // If he further wants to perfrom some action, call main function again
    main();
  } else if (opt == 'W' || opt == 'w') {
    // wants to withdraw amount
    withdrawal();
    main();
  } else if (opt == 'D' || opt == 'd') {
    // Wants to deposit amount
    deposit();
    main();
  } else if (opt == 'B' || opt == 'b') {
    Balance();
    // If wants to perform further action
    main();
  } else if (opt == 'Q' || opt == 'q') {
    // just quit the program
    quit();
  } else if (opt == 'X' || opt == 'x') {

    deleteAccount();
    main();
  }
  // If user enters invalid option
  else {
    cout << "\n***************Error!!Invalid option...Try "
            "Again!!***************\n"
         << endl;
  }

  return 0;
}
